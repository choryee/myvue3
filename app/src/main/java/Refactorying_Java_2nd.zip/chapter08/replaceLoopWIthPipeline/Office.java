package Refactorying_Java_2nd.chapter08.replaceLoopWIthPipeline;

public class Office {
    String city;
    String phone;

    public Office(String city, String phone) {
        this.city = city;
        this.phone = phone;
    }
}
