package Refactorying_Java_2nd.chapter08.slideStatements;

public class Order {
    int units;
    boolean isRepeat;
}
