package Refactorying_Java_2nd.chapter08.slideStatements;

public class PricingPlan {
    public int unit;
    public double discountFactor;
    int base;
    int discountThreshold;
}
