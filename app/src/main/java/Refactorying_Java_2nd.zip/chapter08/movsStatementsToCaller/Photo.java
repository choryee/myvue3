package Refactorying_Java_2nd.chapter08.movsStatementsToCaller;

import java.time.LocalDateTime;

public class Photo {
    String title;
    String location;
    LocalDateTime date;
}
