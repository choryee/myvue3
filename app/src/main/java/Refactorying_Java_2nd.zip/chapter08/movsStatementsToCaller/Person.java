package Refactorying_Java_2nd.chapter08.movsStatementsToCaller;

public class Person {
    String name;
    Photo photo;
}
