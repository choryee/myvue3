package Refactorying_Java_2nd.chapter08.splitLoop;

public class People {
    int salary;
    int age;
}
