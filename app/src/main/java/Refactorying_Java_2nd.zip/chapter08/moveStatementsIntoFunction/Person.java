package Refactorying_Java_2nd.chapter08.moveStatementsIntoFunction;

public class Person {
    String name;
    Photo photo;
}
