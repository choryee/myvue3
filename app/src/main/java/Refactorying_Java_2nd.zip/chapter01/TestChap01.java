package Refactorying_Java_2nd.chapter01;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class TestChap01 {
    public static void main(String[] args) throws Exception {
       Performance performance1=new Performance("hamlet", 65);
       Play play1=new Play("hamlet", PlayType.TRAGEDY);


        Map<String, Play> playMap=new HashMap<>();
        playMap.put("hamlet", new Play("hamlet", PlayType.TRAGEDY));
        playMap.put("As You Like It", new Play("As You Like It", PlayType.COMEDY));
        Plays plays=new Plays(playMap);

        List<Performance> performances=new ArrayList<>();
        performances.add(performance1);
        Invoice invoice=new Invoice("BigCo", performances);
        StatementData statementData=new StatementData(invoice, plays);

        Statement statement=new Statement();
        System.out.println(statement.statement(invoice, plays));
        System.out.println("--------");
        System.out.println(statement.renderHtml(statementData));


    }
}
