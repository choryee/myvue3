package Refactorying_Java_2nd.chapter01;

import java.awt.*;

public class TestRobot {
    public static void main(String[] args) throws AWTException {
        int x = 100, y =100, width = 100, height = 100;

        java.awt.Robot robot = new java.awt.Robot();

        java.awt.image.BufferedImage image = robot.createScreenCapture(new Rectangle(x, y, width, height));
        System.out.println(image);
    }

}
