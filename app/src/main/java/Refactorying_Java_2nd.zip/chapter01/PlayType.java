package Refactorying_Java_2nd.chapter01;

public enum PlayType {
    TRAGEDY, COMEDY
}
