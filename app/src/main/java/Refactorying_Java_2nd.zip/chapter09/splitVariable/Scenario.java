package Refactorying_Java_2nd.chapter09.splitVariable;

public class Scenario {
    int primaryForce;
    int delay;
    int secondaryForce;
    int mass;
}
