package Refactorying_Java_2nd.chapter09.replaceDerivedVariableWithQuery;

public class Adjustment {
    public int amount;
}
