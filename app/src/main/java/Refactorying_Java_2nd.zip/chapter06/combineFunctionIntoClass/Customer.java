package Refactorying_Java_2nd.chapter06.combineFunctionIntoClass;

public class Customer {
}
