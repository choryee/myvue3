package Refactorying_Java_2nd.chapter06.changeFunctionDeclaration;

public class Customer {
}
