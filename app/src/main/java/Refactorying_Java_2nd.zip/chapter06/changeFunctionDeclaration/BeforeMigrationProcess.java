package Refactorying_Java_2nd.chapter06.changeFunctionDeclaration;

public class BeforeMigrationProcess {
    public double circum(double radius) {
        return 2 * Math.PI * radius;
    }
}
