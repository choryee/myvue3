package Refactorying_Java_2nd.chapter06.changeFunctionDeclaration;

public class AfterSimpleProcess {
    public double circumference(double radius) {
        return 2 * Math.PI * radius;
    }
}
