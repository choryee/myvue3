package Refactorying_Java_2nd.chapter06.splitPhase;

public class PriceData {
    protected int basePrice;
    protected int quantity;
    protected int discount;
}
