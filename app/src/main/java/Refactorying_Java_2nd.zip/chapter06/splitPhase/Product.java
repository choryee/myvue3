package Refactorying_Java_2nd.chapter06.splitPhase;

public class Product {
    protected int basePrice;
    protected int discountRate;
    protected int discountThreshold;
}
