package Refactorying_Java_2nd.chapter06.splitPhase;

public class ShippingMethod {
    protected int discountThreshold;
    protected int discountFee;
    protected int feePerCase;
}
