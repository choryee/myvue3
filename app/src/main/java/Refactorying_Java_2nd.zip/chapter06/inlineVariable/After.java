package Refactorying_Java_2nd.chapter06.inlineVariable;

public class After {
    public boolean method(Order order) {
        return order.basePrice > 1000;
    }
}
