package Refactorying_Java_2nd.chapter06.inlineVariable;

public class Order {
    protected int basePrice;

    public Order(int basePrice) {
        this.basePrice = basePrice;
    }
}
