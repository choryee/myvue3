package Refactorying_Java_2nd.chapter06.inlineMethod;

public class Driver {
    protected int numberOfLateDeliveries;

    public Driver(int numberOfLateDeliveries) {
        this.numberOfLateDeliveries = numberOfLateDeliveries;
    }
}
