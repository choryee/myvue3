package Refactorying_Java_2nd.chapter11.replaceCommandWithFunction;

public class Provider {
    double connectionCharge;
}
