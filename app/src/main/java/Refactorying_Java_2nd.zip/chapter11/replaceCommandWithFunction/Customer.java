package Refactorying_Java_2nd.chapter11.replaceCommandWithFunction;

public class Customer {
    double baseRate;
}
