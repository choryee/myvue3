package Refactorying_Java_2nd.chapter11.removeFlagArgument;

import java.time.LocalDateTime;

public class Order {
    LocalDateTime placeOn;
    String deliveryState;
}
