package Refactorying_Java_2nd.chapter11.replaceExceptionWithPrecheck;

public class Resource {
    public static Resource create() {
        return new Resource();
    }
}
