package Refactorying_Java_2nd.chapter11.replaceQueryWithParameter;

public class Thermostat {
    public static int selectedTemperature;
    public static int currentTemperature;
}
