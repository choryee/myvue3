package Refactorying_Java_2nd.chapter11.returnModifiedValue;

public class Point {
    int elevation;
}
