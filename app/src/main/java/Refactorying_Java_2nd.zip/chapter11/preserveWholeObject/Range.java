package Refactorying_Java_2nd.chapter11.preserveWholeObject;

public class Range {
    int low;
    int high;
}
