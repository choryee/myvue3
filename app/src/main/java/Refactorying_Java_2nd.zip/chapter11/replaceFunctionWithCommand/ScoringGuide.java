package Refactorying_Java_2nd.chapter11.replaceFunctionWithCommand;

public class ScoringGuide {
    public boolean stateWithLowCertification(String originalState) {
        return false;
    }
}
