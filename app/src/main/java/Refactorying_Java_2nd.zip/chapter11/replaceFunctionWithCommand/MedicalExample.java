package Refactorying_Java_2nd.chapter11.replaceFunctionWithCommand;

public class MedicalExample {
    boolean isSmoker;
}
