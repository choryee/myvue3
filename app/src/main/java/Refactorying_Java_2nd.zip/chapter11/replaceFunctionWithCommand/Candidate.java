package Refactorying_Java_2nd.chapter11.replaceFunctionWithCommand;

public class Candidate {
    public String originalState;
}
