package Refactorying_Java_2nd.chapter11.separteQueryFromModifier;

public class Person {
    String name;
}
