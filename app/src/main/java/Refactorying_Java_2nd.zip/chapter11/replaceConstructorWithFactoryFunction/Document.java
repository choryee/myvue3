package Refactorying_Java_2nd.chapter11.replaceConstructorWithFactoryFunction;

public class Document {
    String name;
    String empType;
    String leadEngineer;
}
