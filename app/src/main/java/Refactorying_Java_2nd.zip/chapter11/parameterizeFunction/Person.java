package Refactorying_Java_2nd.chapter11.parameterizeFunction;

public class Person {
    int salary;
}
