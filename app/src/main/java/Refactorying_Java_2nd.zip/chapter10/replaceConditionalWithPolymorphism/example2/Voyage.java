package Refactorying_Java_2nd.chapter10.replaceConditionalWithPolymorphism.example2;

public class Voyage {
    public String zone;
    public int length;
    public int profit;
}
