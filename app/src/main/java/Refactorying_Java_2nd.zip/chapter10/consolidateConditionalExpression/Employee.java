package Refactorying_Java_2nd.chapter10.consolidateConditionalExpression;

public class Employee {
    int seniority;
    int monthDisabled;
    boolean isPartTime;
}
