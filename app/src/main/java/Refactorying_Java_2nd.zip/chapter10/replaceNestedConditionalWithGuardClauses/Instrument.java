package Refactorying_Java_2nd.chapter10.replaceNestedConditionalWithGuardClauses;

public class Instrument {
    int capital;
    double interRate;
    int duration;
    int income;
    double adjustmentFactor;
}
