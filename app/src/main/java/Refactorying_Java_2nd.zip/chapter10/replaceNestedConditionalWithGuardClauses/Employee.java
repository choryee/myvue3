package Refactorying_Java_2nd.chapter10.replaceNestedConditionalWithGuardClauses;

public class Employee {
    boolean isSeparated;
    boolean isRetired;
}
