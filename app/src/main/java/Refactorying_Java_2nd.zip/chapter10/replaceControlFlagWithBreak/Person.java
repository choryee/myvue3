package Refactorying_Java_2nd.chapter10.replaceControlFlagWithBreak;

public class Person {
    String name;
}
