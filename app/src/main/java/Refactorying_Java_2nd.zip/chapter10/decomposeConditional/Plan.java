package Refactorying_Java_2nd.chapter10.decomposeConditional;

import java.time.LocalDateTime;

public class Plan {
    LocalDateTime summerStart;
    LocalDateTime summerEnd;
    double summerRate;
    double regularRate;
    int regularServiceCharge;
}
