package Refactorying_Java_2nd.chapter07.replaceTempWithQuery;

public class Item {
    protected int price;

    public Item(int price) {
        this.price = price;
    }
}
