package Refactorying_Java_2nd.chapter12.pullUpMethod;

public class Employee extends Party {

}
