package Refactorying_Java_2nd.chapter12.removeSubClass;

public class Data {
    String name;
    String gender;
}
