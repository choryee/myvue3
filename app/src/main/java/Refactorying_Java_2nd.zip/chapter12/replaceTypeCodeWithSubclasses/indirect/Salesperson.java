package Refactorying_Java_2nd.chapter12.replaceTypeCodeWithSubclasses.indirect;

public class Salesperson extends EmployeeType {

}
