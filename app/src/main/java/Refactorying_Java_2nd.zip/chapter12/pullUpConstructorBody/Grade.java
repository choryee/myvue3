package Refactorying_Java_2nd.chapter12.pullUpConstructorBody;

public class Grade {
    int val;
}
