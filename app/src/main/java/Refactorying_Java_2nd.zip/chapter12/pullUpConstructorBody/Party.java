package Refactorying_Java_2nd.chapter12.pullUpConstructorBody;

public class Party {
    String name;

    public Party(String name) {
        this.name = name;
    }
}
