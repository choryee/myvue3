package Refactorying_Java_2nd.chapter12.extractSuperclass;

import java.util.List;

public class Staff {
    int length;
    List<Employee> employees;
}
