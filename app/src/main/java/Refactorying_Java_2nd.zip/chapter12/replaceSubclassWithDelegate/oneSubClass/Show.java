package Refactorying_Java_2nd.chapter12.replaceSubclassWithDelegate.oneSubClass;

public class Show {
    boolean talkback;
    int price;
}
