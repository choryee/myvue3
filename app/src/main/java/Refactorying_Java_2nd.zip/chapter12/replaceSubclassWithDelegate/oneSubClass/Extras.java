package Refactorying_Java_2nd.chapter12.replaceSubclassWithDelegate.oneSubClass;

public class Extras {
    int premiumFee;
    boolean dinner;
}
