package Refactorying_Java_2nd.chapter12.replaceSubclassWithDelegate.multiSubClass;

public class Data {
    boolean isNailed;
    int voltage;
    int numberOfCounts;
    String type;
    String name;
    String plumage;
}
